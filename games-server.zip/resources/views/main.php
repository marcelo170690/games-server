<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>API</title>
    <style>
        .bg-purple{
            background-color: #7953af;
            color: white;
            border-radius: 15px;
            width: 100%;
            text-align: center;
            padding-bottom: 20px;
            padding-top: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="bg-purple">
            Welcome to games's api, development for <b>team 7 binary</b>
        </div>
    </div>
</body>
</html>
