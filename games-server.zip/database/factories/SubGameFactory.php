<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\SubGame;
use Faker\Generator as Faker;

$factory->define(SubGame::class, function (Faker $faker) {
    return [
        //
    ];
});
