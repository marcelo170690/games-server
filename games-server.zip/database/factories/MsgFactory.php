<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Msg;
use Faker\Generator as Faker;

$factory->define(Msg::class, function (Faker $faker) {
    return [
        //
    ];
});
